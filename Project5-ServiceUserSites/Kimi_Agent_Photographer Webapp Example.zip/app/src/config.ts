// ============================================================================
// Site Configuration
// ============================================================================

export interface SiteConfig {
  title: string;
  description: string;
  language: string;
}

export const siteConfig: SiteConfig = {
  title: "Elena Voss Photography | Fashion & Portrait Studio NYC",
  description: "Award-winning fashion and portrait photographer based in New York City. Specializing in editorial, luxury brand campaigns, and artistic portraiture with dramatic cinematic lighting.",
  language: "en",
};

// ============================================================================
// Navigation Configuration
// ============================================================================

export interface NavItem {
  label: string;
  href: string;
}

export interface NavigationConfig {
  logo: string;
  items: NavItem[];
}

export const navigationConfig: NavigationConfig = {
  logo: "ELENA VOSS",
  items: [
    { label: "Works", href: "#works" },
    { label: "About", href: "#about" },
    { label: "Services", href: "#services" },
    { label: "Pricing", href: "#pricing" },
    { label: "Blog", href: "#blog" },
    { label: "Contact", href: "#contact" },
  ],
};

// ============================================================================
// Hero Section Configuration
// ============================================================================

export interface HeroConfig {
  title: string;
  subtitle: string;
  backgroundImage: string;
  servicesLabel: string;
  copyright: string;
}

export const heroConfig: HeroConfig = {
  title: "VOSS",
  subtitle: "Where Light Meets Artistry",
  backgroundImage: "/hero-main.jpg",
  servicesLabel: "Fashion | Portrait | Editorial",
  copyright: "© 2024 Elena Voss Photography",
};

// ============================================================================
// About Section Configuration
// ============================================================================

export interface AboutConfig {
  titleLine1: string;
  titleLine2: string;
  description: string;
  image1: string;
  image1Alt: string;
  image2: string;
  image2Alt: string;
  authorImage: string;
  authorName: string;
  authorBio: string;
}

export const aboutConfig: AboutConfig = {
  titleLine1: "I believe every photograph should tell a story",
  titleLine2: "that transcends the ordinary and captures the soul.",
  description: "Based in the heart of New York City, I've spent over a decade crafting visual narratives for luxury brands, fashion houses, and discerning clients worldwide. My approach blends classical lighting techniques with contemporary artistic vision, creating images that are both timeless and strikingly modern.",
  image1: "/about-1.jpg",
  image1Alt: "Elena Voss directing a fashion photoshoot",
  image2: "/about-2.jpg",
  image2Alt: "Professional camera equipment in studio",
  authorImage: "/photographer.jpg",
  authorName: "Elena Voss",
  authorBio: "Award-winning photographer with features in Vogue, Harper's Bazaar, and Elle. Trained at Parsons School of Design, I've collaborated with brands like Chanel, Dior, and Tiffany & Co. My work explores the intersection of light, emotion, and human connection.",
};

// ============================================================================
// Works Section Configuration
// ============================================================================

export interface WorkItem {
  id: number;
  title: string;
  category: string;
  image: string;
}

export interface WorksConfig {
  title: string;
  subtitle: string;
  projects: WorkItem[];
}

export const worksConfig: WorksConfig = {
  title: "Selected Works",
  subtitle: "A curated collection of campaigns and editorial features.",
  projects: [
    { 
      id: 1, 
      title: "Metallic Dreams", 
      category: "Editorial", 
      image: "/work-1.jpg" 
    },
    { 
      id: 2, 
      title: "Midnight Elegance", 
      category: "Brand Campaign", 
      image: "/work-2.jpg" 
    },
    { 
      id: 3, 
      title: "Floral Whispers", 
      category: "Beauty", 
      image: "/work-3.jpg" 
    },
    { 
      id: 4, 
      title: "Crimson Movement", 
      category: "Couture", 
      image: "/work-4.jpg" 
    },
  ],
};

// ============================================================================
// Services Section Configuration
// ============================================================================

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  image: string;
}

export interface ServicesConfig {
  title: string;
  subtitle: string;
  services: ServiceItem[];
}

export const servicesConfig: ServicesConfig = {
  title: "Our Craft",
  subtitle: "Every project is an opportunity to create something extraordinary.",
  services: [
    { 
      id: "01", 
      title: "Editorial Photography", 
      description: "High-fashion editorial shoots for magazines, lookbooks, and brand campaigns. From concept to final image, we create visually striking narratives.", 
      image: "/service-1.jpg" 
    },
    { 
      id: "02", 
      title: "Brand Campaigns", 
      description: "Luxury product photography and brand storytelling that elevates your products and connects with your audience on an emotional level.", 
      image: "/service-2.jpg" 
    },
    { 
      id: "03", 
      title: "Portrait Sessions", 
      description: "Intimate portrait photography for executives, artists, and individuals seeking authentic, compelling imagery that captures their essence.", 
      image: "/service-3.jpg" 
    },
    { 
      id: "04", 
      title: "Post-Production", 
      description: "Expert retouching, color grading, and image enhancement. We ensure every pixel meets the highest standards of excellence.", 
      image: "/service-4.jpg" 
    },
  ],
};

// ============================================================================
// Testimonials Section Configuration
// ============================================================================

export interface TestimonialItem {
  id: number;
  name: string;
  title: string;
  quote: string;
  image: string;
}

export interface TestimonialsConfig {
  title: string;
  testimonials: TestimonialItem[];
}

export const testimonialsConfig: TestimonialsConfig = {
  title: "Client Voices",
  testimonials: [
    { 
      id: 1, 
      name: "Victoria Ashford", 
      title: "Creative Director, Lumière Magazine", 
      quote: "Elena's ability to capture emotion through light is unparalleled. Every shoot exceeds our expectations and delivers covers that stop traffic.", 
      image: "/testimonial-1.jpg" 
    },
    { 
      id: 2, 
      name: "Marcus Chen", 
      title: "CEO, Aurum Luxury Group", 
      quote: "Working with Elena transformed our brand imagery. Her attention to detail and artistic vision elevated our campaigns to a new level of sophistication.", 
      image: "/testimonial-2.jpg" 
    },
    { 
      id: 3, 
      name: "Sophie Laurent", 
      title: "Marketing Director, Maison Belle", 
      quote: "Elena doesn't just take photographs—she creates art. Her portraits captured the essence of our brand perfectly. Absolutely magical work.", 
      image: "/testimonial-3.jpg" 
    },
  ],
};

// ============================================================================
// Pricing Section Configuration
// ============================================================================

export interface PricingPlan {
  id: number;
  name: string;
  price: number;
  unit: string;
  featured: boolean;
  features: string[];
}

export interface PricingConfig {
  title: string;
  subtitle: string;
  ctaButtonText: string;
  plans: PricingPlan[];
}

export const pricingConfig: PricingConfig = {
  title: "Investment",
  subtitle: "Premium packages crafted for exceptional results.",
  ctaButtonText: "Inquire Now",
  plans: [
    { 
      id: 1, 
      name: "Essential", 
      price: 2500, 
      unit: "per session", 
      featured: false, 
      features: [
        "3-hour studio session",
        "Professional styling consultation",
        "15 retouched images",
        "Online gallery",
        "Commercial usage rights"
      ] 
    },
    { 
      id: 2, 
      name: "Signature", 
      price: 5500, 
      unit: "per session", 
      featured: true, 
      features: [
        "Full-day shoot (8 hours)",
        "Hair & makeup artist included",
        "Multiple looks/wardrobe changes",
        "35 retouched images",
        "Priority delivery (1 week)",
        "Behind-the-scenes video"
      ] 
    },
    { 
      id: 3, 
      name: "Campaign", 
      price: 12000, 
      unit: "per project", 
      featured: false, 
      features: [
        "Multi-day production",
        "Full creative team",
        "Location scouting & permits",
        "100+ retouched images",
        "Rush delivery available",
        "Usage rights negotiation"
      ] 
    },
  ],
};

// ============================================================================
// FAQ Section Configuration
// ============================================================================

export interface FAQItem {
  question: string;
  answer: string;
}

export interface FAQConfig {
  title: string;
  faqs: FAQItem[];
}

export const faqConfig: FAQConfig = {
  title: "FAQ",
  faqs: [
    { 
      question: "What is your typical turnaround time?", 
      answer: "For portrait sessions, you can expect your fully retouched gallery within 2-3 weeks. Editorial and campaign work typically takes 3-4 weeks depending on the scope. Rush delivery is available for time-sensitive projects." 
    },
    { 
      question: "Do you travel for destination shoots?", 
      answer: "Absolutely. I regularly travel for campaigns and editorial work worldwide. My passport is always ready, and I've shot on location across Europe, Asia, and the Americas. Travel fees are calculated based on destination and duration." 
    },
    { 
      question: "How do I prepare for my session?", 
      answer: "After booking, you'll receive a comprehensive preparation guide covering wardrobe, skincare, and what to expect. We'll also schedule a pre-shoot consultation to discuss your vision, preferences, and any specific shots you'd like to capture." 
    },
    { 
      question: "Can you help with creative direction?", 
      answer: "Creative direction is integral to my process. From mood boards and location scouting to styling and post-production, I work closely with clients to ensure every image aligns with their vision and brand identity." 
    },
    { 
      question: "What are your payment terms?", 
      answer: "A 50% retainer is required to secure your date, with the remaining balance due before final delivery. For larger campaigns, we can arrange milestone-based payments. All major credit cards and wire transfers are accepted." 
    },
  ],
};

// ============================================================================
// Blog Section Configuration
// ============================================================================

export interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  readTime: string;
  date: string;
  image: string;
  category: string;
}

export interface BlogConfig {
  title: string;
  subtitle: string;
  allPostsLabel: string;
  readMoreLabel: string;
  readTimePrefix: string;
  posts: BlogPost[];
}

export const blogConfig: BlogConfig = {
  title: "Studio Notes",
  subtitle: "Insights from our creative journey.",
  allPostsLabel: "All Posts",
  readMoreLabel: "Read More",
  readTimePrefix: "Read ",
  posts: [
    { 
      id: 1, 
      title: "Chasing Golden Hour: The Magic of Natural Light", 
      excerpt: "Why the hour before sunset remains my favorite time to shoot, and how to harness its transformative power in your own photography.", 
      readTime: "6 min", 
      date: "Feb 28, 2024", 
      image: "/blog-1.jpg", 
      category: "Technique" 
    },
    { 
      id: 2, 
      title: "The Art of Three-Point Lighting", 
      excerpt: "A deep dive into the classic lighting setup that forms the foundation of professional portrait and fashion photography.", 
      readTime: "8 min", 
      date: "Feb 15, 2024", 
      image: "/blog-2.jpg", 
      category: "Education" 
    },
  ],
};

// ============================================================================
// Contact Section Configuration
// ============================================================================

export interface ContactFormOption {
  value: string;
  label: string;
}

export interface ContactConfig {
  title: string;
  subtitle: string;
  nameLabel: string;
  emailLabel: string;
  projectTypeLabel: string;
  projectTypePlaceholder: string;
  projectTypeOptions: ContactFormOption[];
  messageLabel: string;
  submitButtonText: string;
  image: string;
}

export const contactConfig: ContactConfig = {
  title: "Let's Create Together",
  subtitle: "Your vision deserves an extraordinary presentation. Let's discuss how we can bring it to life.",
  nameLabel: "Name *",
  emailLabel: "Email *",
  projectTypeLabel: "Project Type",
  projectTypePlaceholder: "Select project type...",
  projectTypeOptions: [
    { value: "editorial", label: "Editorial Photography" },
    { value: "brand", label: "Brand Campaign" },
    { value: "portrait", label: "Portrait Session" },
    { value: "product", label: "Product Photography" },
    { value: "other", label: "Other" },
  ],
  messageLabel: "Tell me about your project",
  submitButtonText: "Send Message",
  image: "/contact.jpg",
};

// ============================================================================
// Footer Configuration
// ============================================================================

export interface FooterLink {
  label: string;
  href: string;
  icon?: string;
}

export interface FooterConfig {
  marqueeText: string;
  marqueeHighlightChars: string[];
  navLinks1: FooterLink[];
  navLinks2: FooterLink[];
  ctaText: string;
  ctaHref: string;
  copyright: string;
  tagline: string;
}

export const footerConfig: FooterConfig = {
  marqueeText: "Every Vision Deserves to Be Captured",
  marqueeHighlightChars: ["V", "C"],
  navLinks1: [
    { label: "Home", href: "#hero" },
    { label: "Works", href: "#works" },
    { label: "About", href: "#about" },
    { label: "Services", href: "#services" },
  ],
  navLinks2: [
    { label: "Instagram", href: "https://instagram.com", icon: "Instagram" },
    { label: "Contact", href: "#contact" },
    { label: "Pricing", href: "#pricing" },
    { label: "Blog", href: "#blog" },
  ],
  ctaText: "Start a Project",
  ctaHref: "#contact",
  copyright: "© 2024 Elena Voss Photography. All rights reserved.",
  tagline: "Crafted with light and passion",
};
