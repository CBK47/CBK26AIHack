// Site-wide configuration
export interface SiteConfig {
  language: string;
  siteName: string;
  siteDescription: string;
}

export const siteConfig: SiteConfig = {
  language: "en",
  siteName: "Serenity Wellness Studio",
  siteDescription: "A sanctuary for mind, body, and soul. Discover holistic wellness through yoga, meditation, and therapeutic treatments.",
};

// Hero Section
export interface HeroConfig {
  backgroundImage: string;
  backgroundAlt: string;
  title: string;
  subtitle: string;
}

export const heroConfig: HeroConfig = {
  backgroundImage: "/hero-bg.jpg",
  backgroundAlt: "Serene wellness studio interior with natural lighting",
  title: "Serenity",
  subtitle: "WELLNESS STUDIO",
};

// Narrative Text Section
export interface NarrativeTextConfig {
  line1: string;
  line2: string;
  line3: string;
}

export const narrativeTextConfig: NarrativeTextConfig = {
  line1: "Find your center",
  line2: "in a world that never stops",
  line3: "We believe wellness is not a destination but a journey. Our sanctuary offers a peaceful retreat where ancient practices meet modern mindfulness, guiding you toward balance, clarity, and inner peace.",
};

// ZigZag Grid Section
export interface ZigZagGridItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  image: string;
  imageAlt: string;
  reverse: boolean;
}

export interface ZigZagGridConfig {
  sectionLabel: string;
  sectionTitle: string;
  items: ZigZagGridItem[];
}

export const zigZagGridConfig: ZigZagGridConfig = {
  sectionLabel: "OUR OFFERINGS",
  sectionTitle: "Pathways to Wellness",
  items: [
    {
      id: "holistic",
      title: "Holistic Healing",
      subtitle: "NATURAL THERAPIES",
      description: "Experience the power of nature with our curated selection of essential oils, herbal remedies, and aromatherapy treatments. Each session is designed to restore harmony to your body and calm your mind using time-honored techniques.",
      image: "/grid-1.jpg",
      imageAlt: "Natural wellness products and essential oils",
      reverse: false,
    },
    {
      id: "sanctuary",
      title: "The Garden Sanctuary",
      subtitle: "OUTDOOR RETREAT",
      description: "Step into our meditation garden, a carefully designed zen space where stone pathways, gentle water features, and bamboo groves create the perfect environment for contemplation and renewal. Open daily for quiet reflection.",
      image: "/grid-2.jpg",
      imageAlt: "Peaceful zen meditation garden with water feature",
      reverse: true,
    },
  ],
};

// Breath Section
export interface BreathSectionConfig {
  backgroundImage: string;
  backgroundAlt: string;
  title: string;
  subtitle: string;
  description: string;
}

export const breathSectionConfig: BreathSectionConfig = {
  backgroundImage: "/breath-bg.jpg",
  backgroundAlt: "Woman practicing yoga at sunrise overlooking mountains",
  title: "Breathe",
  subtitle: "EMBRACE THE MOMENT",
  description: "In the stillness between breaths, we discover who we truly are. Our guided meditation and breathwork sessions help you cultivate presence, reduce stress, and awaken to the beauty of each moment.",
};

// Card Stack Section
export interface CardStackItem {
  id: number;
  image: string;
  title: string;
  description: string;
  rotation: number;
}

export interface CardStackConfig {
  sectionTitle: string;
  sectionSubtitle: string;
  cards: CardStackItem[];
}

export const cardStackConfig: CardStackConfig = {
  sectionTitle: "Journey Inward",
  sectionSubtitle: "EXPERIENCES",
  cards: [
    {
      id: 1,
      image: "/card-1.jpg",
      title: "Mindful Meditation",
      description: "Guided sessions to quiet the mind and awaken inner awareness",
      rotation: -2,
    },
    {
      id: 2,
      image: "/card-2.jpg",
      title: "Therapeutic Massage",
      description: "Healing touch therapies to release tension and restore balance",
      rotation: 1.5,
    },
    {
      id: 3,
      image: "/card-3.jpg",
      title: "Gentle Yoga Flow",
      description: "Movement and breath combined for strength and flexibility",
      rotation: -1,
    },
  ],
};

// Footer Section
export interface FooterContactItem {
  type: "email" | "phone";
  label: string;
  value: string;
  href: string;
}

export interface FooterSocialItem {
  platform: string;
  href: string;
}

export interface FooterConfig {
  heading: string;
  description: string;
  ctaText: string;
  contact: FooterContactItem[];
  locationLabel: string;
  address: string[];
  socialLabel: string;
  socials: FooterSocialItem[];
  logoText: string;
  copyright: string;
  links: { label: string; href: string }[];
}

export const footerConfig: FooterConfig = {
  heading: "Begin Your Journey",
  description: "Take the first step toward a more balanced, peaceful life. Reach out to schedule your visit or learn more about our offerings.",
  ctaText: "Book a Session",
  contact: [
    {
      type: "email",
      label: "hello@serenitystudio.com",
      value: "hello@serenitystudio.com",
      href: "mailto:hello@serenitystudio.com",
    },
    {
      type: "phone",
      label: "+1 (555) 234-5678",
      value: "+15552345678",
      href: "tel:+15552345678",
    },
  ],
  locationLabel: "Location",
  address: [
    "284 Harmony Lane",
    "Malibu, CA 90265",
  ],
  socialLabel: "Follow",
  socials: [
    {
      platform: "instagram",
      href: "https://instagram.com/serenitystudio",
    },
    {
      platform: "facebook",
      href: "https://facebook.com/serenitystudio",
    },
  ],
  logoText: "Serenity",
  copyright: "2025 Serenity Wellness Studio. All rights reserved.",
  links: [
    {
      label: "Privacy Policy",
      href: "/privacy",
    },
    {
      label: "Terms of Service",
      href: "/terms",
    },
  ],
};
