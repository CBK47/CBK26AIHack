// ============================================================================
// SITE CONFIGURATION
// ============================================================================
// Edit this file to customize all content on your site.
// All text, images, and data are controlled from here.
// Do NOT modify component files — only edit this config.
// ============================================================================

// ----------------------------------------------------------------------------
// Navigation
// ----------------------------------------------------------------------------

export interface NavLink {
  label: string;
  href: string;
}

export interface NavigationConfig {
  logo: string;
  logoAccent: string;
  navLinks: NavLink[];
  ctaText: string;
}

export const navigationConfig: NavigationConfig = {
  logo: "TEST",
  logoAccent: ".",
  navLinks: [
    { label: "Products", href: "#products" },
    { label: "Colors", href: "#palette" },
    { label: "About", href: "#finale" },
  ],
  ctaText: "Get Started",
};

// ----------------------------------------------------------------------------
// Hero Section
// ----------------------------------------------------------------------------

export interface HeroConfig {
  titleLine1: string;
  titleLine2: string;
  subtitle: string;
  ctaText: string;
  ctaHref: string;
  backgroundImage: string;
  gridRows: number;
  gridCols: number;
  pinkCells: { row: number; col: number }[];
}

export const heroConfig: HeroConfig = {
  titleLine1: "HOSTING",
  titleLine2: "TEST SITE",
  subtitle: "A bold Swiss Dada style template for testing your hosting provider",
  ctaText: "Explore Features",
  ctaHref: "#products",
  backgroundImage: "/images/hero.jpg",
  gridRows: 6,
  gridCols: 8,
  pinkCells: [
    { row: 0, col: 2 },
    { row: 1, col: 5 },
    { row: 2, col: 0 },
    { row: 3, col: 7 },
    { row: 4, col: 3 },
    { row: 5, col: 6 },
  ],
};

// ----------------------------------------------------------------------------
// Product Showcase Section
// ----------------------------------------------------------------------------

export interface ProductFeature {
  value: string;
  label: string;
}

export interface ProductShowcaseConfig {
  sectionLabel: string;
  headingMain: string;
  headingAccent: string;
  productName: string;
  description: string;
  price: string;
  features: ProductFeature[];
  colorSwatches: string[];
  colorSwatchesLabel: string;
  ctaText: string;
  productImage: string;
  productImageAlt: string;
  decorativeText: string;
}

export const productShowcaseConfig: ProductShowcaseConfig = {
  sectionLabel: "FEATURED PRODUCT",
  headingMain: "Premium ",
  headingAccent: "Experience",
  productName: "TestProduct Pro",
  description: "This is a sample product showcase section. Use this template to demonstrate your hosting provider's capabilities with rich media, animations, and interactive elements.",
  price: "$99",
  features: [
    { value: "99.9%", label: "Uptime" },
    { value: "<50ms", label: "Response" },
    { value: "24/7", label: "Support" },
  ],
  colorSwatches: ["#ff73c3", "#c41e3a", "#4a90d9", "#f5a623"],
  colorSwatchesLabel: "Available Colors",
  ctaText: "Buy Now",
  productImage: "/images/product.png",
  productImageAlt: "Test Product Pro",
  decorativeText: "PRODUCT",
};

// ----------------------------------------------------------------------------
// Color Palette Section
// ----------------------------------------------------------------------------

export interface ColorSwatch {
  name: string;
  nameSecondary: string;
  color: string;
  description: string;
}

export interface ColorPaletteConfig {
  sectionLabel: string;
  headingMain: string;
  headingAccent: string;
  colors: ColorSwatch[];
  bottomText: string;
  decorativeText: string;
}

export const colorPaletteConfig: ColorPaletteConfig = {
  sectionLabel: "COLOR PALETTE",
  headingMain: "Express Your ",
  headingAccent: "Style",
  colors: [
    {
      name: "Hot Pink",
      nameSecondary: "Neon",
      color: "#ff73c3",
      description: "Bold and vibrant accent color",
    },
    {
      name: "Crimson",
      nameSecondary: "Red",
      color: "#c41e3a",
      description: "Deep passionate red tone",
    },
    {
      name: "Ocean",
      nameSecondary: "Blue",
      color: "#4a90d9",
      description: "Calm and professional blue",
    },
    {
      name: "Golden",
      nameSecondary: "Amber",
      color: "#f5a623",
      description: "Warm golden highlight",
    },
    {
      name: "Emerald",
      nameSecondary: "Green",
      color: "#50c878",
      description: "Fresh natural green",
    },
    {
      name: "Violet",
      nameSecondary: "Purple",
      color: "#8b5cf6",
      description: "Creative purple energy",
    },
  ],
  bottomText: "Click any color to see the particle effect animation",
  decorativeText: "COLORS",
};

// ----------------------------------------------------------------------------
// Finale / Brand Philosophy Section
// ----------------------------------------------------------------------------

export interface FinaleConfig {
  sectionLabel: string;
  headingMain: string;
  headingAccent: string;
  tagline: string;
  features: string[];
  ctaText: string;
  ctaHref: string;
  image: string;
  imageAlt: string;
  decorativeText: string;
}

export const finaleConfig: FinaleConfig = {
  sectionLabel: "BRAND PHILOSOPHY",
  headingMain: "Test Your",
  headingAccent: "Hosting",
  tagline: "This template showcases advanced web technologies including GSAP animations, 3D transforms, scroll-triggered effects, and interactive elements. Perfect for stress-testing your hosting infrastructure.",
  features: ["Fast Loading", "Responsive", "Animated", "Interactive"],
  ctaText: "Start Testing",
  ctaHref: "#",
  image: "/images/brand-portrait.jpg",
  imageAlt: "Brand Portrait",
  decorativeText: "TEST",
};

// ----------------------------------------------------------------------------
// Footer
// ----------------------------------------------------------------------------

export interface SocialLink {
  platform: "instagram" | "twitter" | "youtube";
  href: string;
  label: string;
}

export interface FooterLinkSection {
  title: string;
  links: string[];
}

export interface ContactInfo {
  address: string;
  phone: string;
  email: string;
}

export interface LegalLink {
  label: string;
  href: string;
}

export interface FooterConfig {
  logo: string;
  logoAccent: string;
  brandDescription: string;
  socialLinks: SocialLink[];
  linkSections: FooterLinkSection[];
  contact: ContactInfo;
  legalLinks: LegalLink[];
  copyrightText: string;
  decorativeText: string;
}

export const footerConfig: FooterConfig = {
  logo: "TEST",
  logoAccent: ".",
  brandDescription: "A Swiss Dada style template for testing hosting providers with bold design and rich interactions.",
  socialLinks: [
    { platform: "instagram", href: "#", label: "Instagram" },
    { platform: "twitter", href: "#", label: "Twitter" },
    { platform: "youtube", href: "#", label: "YouTube" },
  ],
  linkSections: [
    { title: "Products", links: ["All Products", "New Arrivals", "Best Sellers"] },
    { title: "Support", links: ["FAQ", "Contact Us", "Documentation"] },
    { title: "Company", links: ["About", "Careers", "Press"] },
  ],
  contact: {
    address: "123 Test Street, Demo City, 12345",
    phone: "+1 (555) 123-4567",
    email: "hello@testsite.com",
  },
  legalLinks: [
    { label: "Privacy Policy", href: "#" },
    { label: "Terms of Service", href: "#" },
    { label: "Cookie Policy", href: "#" },
  ],
  copyrightText: "Test Site. All rights reserved.",
  decorativeText: "TEST",
};

// ----------------------------------------------------------------------------
// Site Metadata
// ----------------------------------------------------------------------------

export interface SiteConfig {
  title: string;
  description: string;
  language: string;
}

export const siteConfig: SiteConfig = {
  title: "Hosting Test Site",
  description: "A bold Swiss Dada style template for testing hosting providers",
  language: "en",
};
